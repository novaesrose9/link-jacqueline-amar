import { perfil, redes } from '../config/links.js'

export default function Rodape() {
  const temRedes = Boolean(redes.instagram || redes.youtube || redes.site)

  return (
    <footer className="rodape">
      {temRedes && (
        <div className="rodape__redes">
          {redes.instagram && (
            <a
              className="rodape__icone"
              href={redes.instagram}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram"
            >
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.4"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <rect x="3" y="3" width="18" height="18" rx="5" />
                <circle cx="12" cy="12" r="4" />
                <circle cx="17.2" cy="6.8" r="1" fill="currentColor" stroke="none" />
              </svg>
            </a>
          )}

          {redes.youtube && (
            <a
              className="rodape__icone"
              href={redes.youtube}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="YouTube"
            >
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.4"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <rect x="2.5" y="5" width="19" height="14" rx="4.5" />
                <path d="M10.4 9.3l4.6 2.7-4.6 2.7V9.3z" fill="currentColor" stroke="none" />
              </svg>
            </a>
          )}

          {redes.site && (
            <a
              className="rodape__icone"
              href={redes.site}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Site oficial"
            >
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.4"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <circle cx="12" cy="12" r="9" />
                <path d="M3.4 9h17.2M3.4 15h17.2" />
                <path d="M12 3c2.4 2.6 3.6 5.6 3.6 9s-1.2 6.4-3.6 9c-2.4-2.6-3.6-5.6-3.6-9S9.6 5.6 12 3z" />
              </svg>
            </a>
          )}
        </div>
      )}

      <p className="rodape__texto">{perfil.rodape}</p>
      <p className="rodape__copy">{perfil.copyright}</p>
    </footer>
  )
}
