/**
 * Linha de batimento cardíaco (ECG) com um pulso dourado que percorre o traço.
 * O desenho fica no traçado abaixo; a animação está em `.batimento` no app.css.
 */
const TRACADO =
  'M0 20 H74 l5 -4 l4 9 l5 -22 l6 30 l5 -13 l4 0 H180 l5 -4 l4 9 l5 -22 l6 30 l5 -13 l4 0 H240'

export default function Batimento() {
  return (
    <svg
      className="batimento"
      viewBox="0 0 240 40"
      fill="none"
      preserveAspectRatio="xMidYMid meet"
      aria-hidden="true"
    >
      {/* traço de base, bem suave */}
      <path className="batimento__base" d={TRACADO} />
      {/* pulso que percorre a linha */}
      <path className="batimento__pulso" d={TRACADO} pathLength="1" />
    </svg>
  )
}
