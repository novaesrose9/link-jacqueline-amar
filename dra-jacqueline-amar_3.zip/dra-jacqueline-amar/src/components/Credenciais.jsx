import { credenciais } from '../config/links.js'

export default function Credenciais() {
  if (!credenciais?.length) return null

  return (
    <section className="credenciais" aria-label="Formação">
      <ul className="credenciais__lista">
        {credenciais.map((item) => (
          <li className="credenciais__item" key={item}>
            {item}
          </li>
        ))}
      </ul>
    </section>
  )
}
