export default function Botao({ titulo, descricao, url, destaque = false, atraso = 0 }) {
  return (
    <a
      className={`botao${destaque ? ' botao--destaque' : ''}`}
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      style={{ animationDelay: `${atraso}s` }}
    >
      <span className="botao__texto">
        <span className="botao__titulo">{titulo}</span>
        <span className="botao__descricao">{descricao}</span>
      </span>

      <span className="botao__seta" aria-hidden="true">
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.6"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M5 12h13M13 6l6 6-6 6" />
        </svg>
      </span>
    </a>
  )
}
