import { useEffect, useRef, useState } from 'react'
import Batimento from './Batimento.jsx'
import foto from '../assets/dra-jacqueline-amar.jpg'
import { perfil } from '../config/links.js'

export default function Perfil({ nome, titulo, frase }) {
  const [aberto, setAberto] = useState(false)
  const selo = useRef(null)

  // fecha o popup ao clicar fora ou apertar Esc
  useEffect(() => {
    if (!aberto) return

    function aoClicarFora(evento) {
      if (selo.current && !selo.current.contains(evento.target)) setAberto(false)
    }
    function aoTeclar(evento) {
      if (evento.key === 'Escape') setAberto(false)
    }

    document.addEventListener('pointerdown', aoClicarFora)
    document.addEventListener('keydown', aoTeclar)
    return () => {
      document.removeEventListener('pointerdown', aoClicarFora)
      document.removeEventListener('keydown', aoTeclar)
    }
  }, [aberto])

  return (
    <header className="perfil">
      <div className="perfil__moldura">
        {/* Anéis dourados em movimento contínuo */}
        <span className="perfil__anel perfil__anel--externo" aria-hidden="true" />
        <span className="perfil__anel perfil__anel--interno" aria-hidden="true" />
        <span className="perfil__orbita" aria-hidden="true" />

        <img
          className="perfil__foto"
          src={foto}
          alt={`Retrato de ${nome}`}
          width="800"
          height="800"
          fetchPriority="high"
          decoding="async"
        />

        {/* Selo do RQE, com popup explicativo */}
        <div className="selo" ref={selo}>
          <button
            type="button"
            className="selo__botao"
            aria-expanded={aberto}
            onClick={() => setAberto((valor) => !valor)}
          >
            {perfil.rqe}
          </button>

          <span className={`selo__popup${aberto ? ' selo__popup--aberto' : ''}`} role="tooltip">
            {perfil.rqeDescricao}
          </span>
        </div>
      </div>

      <h1 className="perfil__nome">{nome}</h1>
      <p className="perfil__titulo">{titulo}</p>

      <p className="perfil__frase">{frase}</p>

      <Batimento />
    </header>
  )
}
