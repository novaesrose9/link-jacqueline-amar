import { useEffect, useRef } from 'react'

/**
 * Fundo branco com pontinhos dourados piscando, como um céu discreto.
 * Ajustes rápidos: DENSIDADE (quantidade), OPACIDADE_MAXIMA (brilho) e
 * VELOCIDADE (ritmo do pisca-pisca).
 */
const DENSIDADE = 13000 // 1 ponto a cada X pixels de tela — maior = menos pontos
const RAIO_MINIMO = 0.35 // tamanho dos pontinhos, em pixels
const RAIO_VARIACAO = 0.7 // o quanto o tamanho varia de um ponto para outro
const OPACIDADE_MAXIMA = 0.6
const VELOCIDADE = 0.55
const COR = '220, 179, 63' // #dcb33f em RGB

export default function CeuDourado() {
  const canvasRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    const semMovimento = window.matchMedia('(prefers-reduced-motion: reduce)').matches

    let pontos = []
    let largura = 0
    let altura = 0
    let quadro
    let inicio

    function preparar() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      largura = canvas.offsetWidth
      altura = canvas.offsetHeight
      canvas.width = largura * dpr
      canvas.height = altura * dpr
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)

      const total = Math.round((largura * altura) / DENSIDADE)
      pontos = Array.from({ length: total }, () => ({
        x: Math.random() * largura,
        y: Math.random() * altura,
        raio: RAIO_MINIMO + Math.random() * RAIO_VARIACAO,
        base: 0.12 + Math.random() * 0.3,
        amplitude: 0.2 + Math.random() * 0.45,
        ritmo: 0.4 + Math.random() * 1.1,
        fase: Math.random() * Math.PI * 2,
      }))
    }

    function desenhar(tempo) {
      if (inicio === undefined) inicio = tempo
      const t = ((tempo - inicio) / 1000) * VELOCIDADE

      ctx.clearRect(0, 0, largura, altura)

      for (const p of pontos) {
        const brilho = semMovimento
          ? p.base + p.amplitude * 0.5
          : p.base + p.amplitude * (0.5 + 0.5 * Math.sin(t * p.ritmo + p.fase))

        const alfa = Math.min(brilho, OPACIDADE_MAXIMA)

        ctx.beginPath()
        ctx.arc(p.x, p.y, p.raio, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(${COR}, ${alfa})`
        ctx.fill()

        // halo suave nos pontos maiores
        if (p.raio > RAIO_MINIMO + RAIO_VARIACAO * 0.65) {
          ctx.beginPath()
          ctx.arc(p.x, p.y, p.raio * 3, 0, Math.PI * 2)
          ctx.fillStyle = `rgba(${COR}, ${alfa * 0.12})`
          ctx.fill()
        }
      }

      if (!semMovimento) quadro = requestAnimationFrame(desenhar)
    }

    function aoRedimensionar() {
      preparar()
      if (semMovimento) requestAnimationFrame(desenhar)
    }

    preparar()
    quadro = requestAnimationFrame(desenhar)
    window.addEventListener('resize', aoRedimensionar)

    return () => {
      cancelAnimationFrame(quadro)
      window.removeEventListener('resize', aoRedimensionar)
    }
  }, [])

  return <canvas ref={canvasRef} className="ceu" aria-hidden="true" />
}
