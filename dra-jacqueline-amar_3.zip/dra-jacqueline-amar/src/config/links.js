/**
 * ─────────────────────────────────────────────────────────────
 *  EDITE APENAS ESTE ARQUIVO PARA ATUALIZAR OS LINKS DA PÁGINA
 * ─────────────────────────────────────────────────────────────
 *  Basta trocar o conteúdo entre as aspas.
 *  Dica: links de WhatsApp seguem o formato
 *  https://wa.me/5511999999999?text=Ola
 */

export const perfil = {
  nome: 'Dra. Jacqueline Amar',
  titulo: 'Médica gerontóloga | Longevidade, Nutrologia e Medicina do Esporte',
  frase:
    'Conhecimento e cuidado para viver mais, com saúde, força e qualidade de vida.',
  rqe: 'RQE 61530',
  rqeDescricao: 'Registro de Qualificação de Especialista nº 61530',
  rodape: 'Dra. Jacqueline Amar | Medicina, saúde e longevidade',
  copyright: '© 2026 Dra. Jacqueline Amar. Todos os direitos reservados.',
}

export const visual = {
  // Fundo branco com pontinhos dourados piscando. Deixe false para desligar.
  ceuDourado: true,
}

export const botoes = [
  {
    titulo: 'Quero participar da próxima aula',
    descricao: 'Entre na lista e receba as informações em primeira mão.',
    url: 'https://chat.whatsapp.com/BsXbxIrOv3q8Buwtx67QgZ?mode=gi_t',
    destaque: true, // botão principal, em azul — use em apenas um item
  },
  {
    titulo: 'Receba minha newsletter semanal',
    descricao: 'Conteúdos sobre longevidade direto no seu e-mail.',
    url: 'https://substack.com/@drajacquelineamar/reads',
  },
  {
    titulo: 'Canal no YouTube',
    descricao: 'Vídeos sobre longevidade, saúde e qualidade de vida.',
    url: 'https://www.youtube.com/@ClinicaDraAmar',
  },
  {
    titulo: 'Assessoria de Imprensa',
    descricao: 'Entrevistas, pautas, eventos e participações.',
    url: 'https://wa.me/5521998797072',
  },
  {
    titulo: 'Falar com a Equipe de Suporte',
    descricao: 'Dúvidas e informações.',
    url: 'https://wa.me/5521998928044',
  },
]

// Formação exibida abaixo dos botões. Remova ou acrescente linhas à vontade.
export const credenciais = [
  'Board Certified in Aging and Regenerative Medicine — USA',
  'Fellow in Clinical Nutrition — Duke University, USA',
  'Especialização em Medicina do Exercício e do Esporte',
]

export const redes = {
  // Ícones do rodapé. Deixe '' para ocultar; preencha para exibir de novo.
  instagram: '', // ex.: 'https://instagram.com/drajacquelineamar'
  youtube: '', // ex.: 'https://www.youtube.com/@ClinicaDraAmar'
  site: '', // ex.: 'https://www.jacquelineamar.com.br'
}
